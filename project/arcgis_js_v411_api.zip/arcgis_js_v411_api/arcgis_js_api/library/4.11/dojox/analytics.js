//>>built
define(["./analytics/_base"],function(a){return a});