//>>built
define(["./html/_base"],function(a){return a});