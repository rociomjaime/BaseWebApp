//>>built
define(["./dtl/_base"],function(a){return a});