//>>built
define(["dojox/uuid/_base"],function(a){return a});