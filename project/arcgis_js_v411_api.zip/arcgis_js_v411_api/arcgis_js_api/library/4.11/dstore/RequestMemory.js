//>>built
define(["dojo/_base/declare","./Request","./Cache"],function(a,b,c){return a([b,c],{postscript:function(){this.inherited(arguments);this.fetch()},isValidFetchCache:!0})});