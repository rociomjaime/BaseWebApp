//>>built
define(["dojo/uacss"],function(){});