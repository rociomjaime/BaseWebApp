//>>built
define(["dojo/_base/declare","./Grid","./OnDemandList"],function(a,b,c){return a([b,c],{})});