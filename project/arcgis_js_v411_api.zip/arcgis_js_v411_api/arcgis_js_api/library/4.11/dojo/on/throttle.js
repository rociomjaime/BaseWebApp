//>>built
define(["../throttle","../on"],function(a,b){return function(c,d){return function(e,f){return b(e,c,a(f,d))}}});