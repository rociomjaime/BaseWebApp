//>>built
define([],function(){return function(b,c){var a=!0;return function(){a&&(a=!1,b.apply(this,arguments),setTimeout(function(){a=!0},c))}}});