//>>built
define(["./create"],function(a){return a("RequestError",function(a,b){this.response=b})});