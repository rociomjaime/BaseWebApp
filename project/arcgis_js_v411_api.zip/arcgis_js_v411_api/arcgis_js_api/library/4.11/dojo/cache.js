//>>built
define(["./_base/kernel","./text"],function(a){return a.cache});